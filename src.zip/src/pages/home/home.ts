import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  pacientes = [
    { Nome: 'João Silva', Telefone: '123456789', Sintomas: ['Dor de cabeça'], Remedios: ['Paracetamol'] },
    { Nome: 'Maria Oliveira', Telefone: '987654321', Sintomas: ['Tosse seca'], Remedios: ['Xarope para tosse'] }
  ];

  constructor(public navCtrl: NavController, public alertCtrl: AlertController) {}

  showPrompt() {
    const prompt = this.alertCtrl.create({
      title: 'Adicionar Paciente',
      message: "Insira os dados do paciente e sintomas:",
      inputs: [
        {
          name: 'Nome',
          placeholder: 'Nome do Paciente',
          type: 'text'
        },
        {
          name: 'Telefone',
          placeholder: 'Número de Telefone',
          type: 'tel'
        },
        {
          name: 'Sintomas',
          placeholder: 'Sintomas (separados por vírgula)',
          type: 'textarea',
          value: ''
        },
        {
          name: 'Remedios',
          placeholder: 'Remédios (separados por vírgula)',
          type: 'text'
        }
      ],
      buttons: [
        {
          text: 'Cancelar',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Adicionar',
          handler: data => {
            if (data.Nome && data.Telefone && data.Sintomas) {
              const sintomas = data.Sintomas.split(',').map(s => s.trim());
              const remedios = data.Remedios ? data.Remedios.split(',').map(r => r.trim()) : [];
              const paciente = { Nome: data.Nome, Telefone: data.Telefone, Sintomas: sintomas, Remedios: remedios };
              this.pacientes.push(paciente);
            } else {
              console.log('Preencha todos os campos obrigatórios');
            }
          }
        }
      ]
    });
    prompt.present();
  }

  excluir(paciente) {
    console.log('Excluir', paciente);

    for (let i = 0; i < this.pacientes.length; i++) {
      const item = this.pacientes[i];
      if (item.Nome === paciente.Nome && item.Telefone === paciente.Telefone) {
        this.pacientes.splice(i, 1);
        break;
      }
    }
  }

  showConfirm(paciente) {
    const confirm = this.alertCtrl.create({
      title: 'Excluir Paciente',
      message: 'Deseja excluir este paciente?',
      buttons: [
        {
          text: 'Cancelar',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Confirmar',
          handler: () => {
            this.excluir(paciente);
          }
        }
      ]
    });
    confirm.present();
  }
}
